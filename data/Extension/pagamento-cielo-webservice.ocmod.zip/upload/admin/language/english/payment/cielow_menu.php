<?php
// Text
$_['text_cielow']           = 'Cielo Webservice';
$_['text_cielow_search']    = 'Transações';
$_['text_cielow_log_debug'] = 'Log de erros';